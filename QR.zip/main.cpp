#include <iostream>
#include <thread>
#include <mutex>
#include "state_machine.cpp"
//#include "QR.cpp"

int main() {

    int car_pos1[2] = {1, 2};
    int car_pos2[2] = {3, 4};
    int car_pos3[2] = {5, 6};
    int source_pos[2] = {7, 8};

    //初始化变量
    string location = "112344";
    int current_1 = 1;
    int current_2 = 1;
    mutex mtx;

    class A {
    public:
        std::string scanQRCode() {
            // 扫描二维码并提取信息
            std::string info = "example QR code info";
            return info;
        }
    };

    //QRCodeDetector detector(0);
    StateMachine machine(car_pos1, car_pos2, car_pos3, source_pos, current_1, current_2, location);
    A a;
    std::thread threadA([&]() {
        while(true){

            std::string info = a.scanQRCode();



            // 当car[2] == {1, 1}并且字符串loc == “”时赋给字符串loc
            if (current_1 == 1 && current_2 == 1 && location.empty()) {
                std::lock_guard<std::mutex> lock(mtx);
                location = info;
                cout << location << endl;

        }}
    });

    std::thread threadB([&]() {
        // 只有在字符串loc！=“”时被唤醒
        while (true) {

            if (!location.empty()) {

                std::lock_guard<std::mutex> lock(mtx);

                machine.run();
            }
        }
    });

    // 等待线程A和线程B的完成
    threadA.join();
    threadB.join();

    return 0;
}